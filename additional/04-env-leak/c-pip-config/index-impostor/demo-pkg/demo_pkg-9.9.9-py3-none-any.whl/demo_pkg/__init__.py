WHOAMI = "NOT the package you meant"
VERSION = "9.9.9"

def hello():
    return f"demo_pkg {VERSION} — {WHOAMI}"
