WHOAMI = "NOT the package you meant"
VERSION = "1.0.0"

def hello():
    return f"demo_pkg {VERSION} — {WHOAMI}"
